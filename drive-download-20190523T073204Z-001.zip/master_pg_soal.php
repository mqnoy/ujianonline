<!DOCTYPE html>
<html>
<head>
	<title>Master PG Soal</title>
</head>
<body>
<h1>Master PG Soal</h1>
	<form action="" method="POST">
		Id PG<input type="text" name="txt_id_pg" /><br>
		Jawaban PG<input type="text" name="txt_jwb_pg" /><br>
		Jawaban Text<input type="text" name="txt_jwb_text" /><br>
		Soal Id<input type="text" name="txt_soal_id" /><br>
		<input type="submit" name="submit" value="Submit" />
	</form>

</body>
</html>