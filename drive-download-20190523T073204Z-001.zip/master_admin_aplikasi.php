<!DOCTYPE html>
<html>
<head>
	<title>Master Admin Aplikasi</title>
</head>
<body>
<h1>Master Admin Aplikasi</h1>
	<form action="" method="POST">
		Id Admin<input type="text" name="txt_id" /><br>
		Username<input type="text" name="txt_username" /><br>
		Password<input type="Password" name="txt_password" /><br>
		<input type="submit" name="submit" value="Submit" />
	</form>

</body>
</html>