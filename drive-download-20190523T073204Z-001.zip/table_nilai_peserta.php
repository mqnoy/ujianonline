<!DOCTYPE html>
<html>
<head>
	<title>Table Nilai Peserta</title>
</head>
<body>
<h1>Table Nilai Peserta</h1>
	<form action="" method="POST">
		Id Siswa<input type="text" name="txt_id_siswa" /><br>
		NIS<input type="text" name="txt_nis" /><br>
		Total Nilai<input type="text" name="txt_total_nilai" /><br>
		Siswa Kelas<input type="text" name="txt_kelas" /><br>
		Soal Id<input type="text" name="txt_soal_id" /><br>
		Tgl Pengerjaan<input type="text" name="txt_tgl" /><br>
		<input type="submit" name="submit" value="Submit" />
	</form>
</body>
</html>