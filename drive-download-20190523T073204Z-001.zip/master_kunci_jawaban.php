<!DOCTYPE html>
<html>
<head>
	<title>Master Kunci Jawaban</title>
</head>
<body>
<h1>Master Kunci Jawaban</h1>
	<form action="" method="POST">
		Id Kucni Jawaban<input type="text" name="txt_id" /><br>
		Soal Id<input type="text" name="txt_soal" /><br>
		Jawaban PG<input type="text" name="txt_pg" /><br>
		Bobot<input type="text" name="txt_bobot" /><br>
		<input type="submit" name="submit" value="Submit" />
	</form>

</body>
</html>