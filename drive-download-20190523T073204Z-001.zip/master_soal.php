<!DOCTYPE html>
<html>
<head>
	<title>Master Soal</title>
</head>
<body>
<h1>Master Soal</h1>
	<form action="" method="POST">
		Id Soal<input type="text" name="txt_id_soal" /><br>
		Text Soal<input type="text" name="txt_text_soal" /><br>
		Mapel<input type="text" name="txt_mapel" /><br>
		
		Soal Kelas<select name="cb_kelas">
			<option value="satu">1</option>
			<option value="dua">2</option>
			<option value="tiga">3</option>
		</select><br>

		<input type="submit" name="submit" value="Submit" />
		
	</form>

</body>
</html>